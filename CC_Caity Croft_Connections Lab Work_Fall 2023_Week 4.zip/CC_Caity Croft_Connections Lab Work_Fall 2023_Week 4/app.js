// const techno_vibe_1_kick = audio

let istechno_vibe_1_kickClicked = false;
let istechno_vibe_1_grooveClicked = false;
let istechno_vibe_1_bassCLicked = false; 


let istechno_vibe_2_kickClicked = false;
let istechno_vibe_2_grooveClicked = false;
let istechno_vibe_2_bassClicked = false;

let istechno_vibe_3_kickClicked = false;
let istechno_vibe_3_grooveClicked = false;
let istechno_vibe_3_bassClicked = false;

let istechno_vibe_4_kickClicked = false;
let istechno_vibe_4_grooveClicked = false;
let istechno_vibe_4_bassClicked = false;

var AudioTechnoKickVibe1 = document.getElementById("audio_techno_vibe_1_kick");
var AudioTechnoGrooveVibe1 = document.getElementById("audio_techno_vibe_1_groove");
var AudioTechnoBassVibe1 = document.getElementById("audio_techno_vibe_1_bass");

var AudioTechnoKickVibe2 = document.getElementById("audio_techno_vibe_2_kick");
var AudioTechnoGrooveVibe2 = document.getElementById("audio_techno_vibe_2_groove");
var AudioTechnoBassVibe2 = document.getElementById("audio_techno_vibe_2_bass");


document.getElementById("play_vibe_1_all").addEventListener("click", function () {
    console.log("techno_vibe_1_PLAYALL_button_works")
    AudioTechnoKickVibe1.play(); 
    AudioTechnoGrooveVibe1.play();
    AudioTechnoBassVibe1.play(); 
}
)


// document.getElementById("techno_vibe_1_kick").addEventListener("click", function () {
//     console.log("techno_vibe_1_kick_button_works")
//     document.getElementById("KICK 1.wav").style.display = "block"
//     isTechnoClicked = true;
//     if (isRockClicked) {
//         isRockClicked = false
//         document.getElementById("rock_image").style.display = "none"

//     }

//     if (isOperaClicked) {
//         isOperaClicked = false
//         document.getElementById("opera_image").style.display = "none"

//     }
// }

// );

// document.getElementById("rock_button").addEventListener("click", function () {
//     console.log("I wanna rock n roll all night")
//     document.getElementById("rock_image").style.display = "block"
//     isRockClicked = true;
//     if (isTechnoClicked) {
//         isTechnoClicked = false
//         document.getElementById("techno_image").style.display = "none"

//     }

//     if (isOperaClicked) {
//         isOperaClicked = false
//         document.getElementById("opera_image").style.display = "none"

//     }
// }

// );


// document.getElementById("opera_button").addEventListener("click", function () {
//     console.log("happy dance")
//     document.getElementById("opera_image").style.display = "block"
//     isOperaClicked = true;
//     if (isTechnoClicked) {
//         isTechnoClicked = false
//         document.getElementById("techno_image").style.display = "none"

//     }
//     if (isRockClicked) {
//         isRockClicked = false
//         document.getElementById("rock_image").style.display = "none"

//     }
// }




// fetch('samples.json')
//     .then(response => response.json())
//     .then(data => {
//         const gridContainer = document.querySelector('.grid-container');
        
//         data.samples.forEach((sample, index) => {
//             const gridItem = document.createElement('div');
//             gridItem.classList.add('grid-item');
            
//             const audio = new Audio(`samples/${sample.filename}`);
//             let isPlaying = false;
            
//             gridItem.addEventListener('click', () => {
//                 if (isPlaying) {
//                     audio.pause();
//                 } else {
//                     audio.currentTime = 0;
//                     audio.play();
//                 }
//                 isPlaying = !isPlaying;
//                 gridItem.style.backgroundColor = isPlaying ? 'green' : '#ccc';
//             });
            
//             gridContainer.appendChild(gridItem);
//         });
//     })
//     .catch(error => console.error(error));
// Step 4: Create the JSON file

// In your samples.json file, define your sample data like this:



// }
// Step 5: Test your application

// Open index.html in a web browser, and you should see your grid of buttons that play music samples when clicked.

// This is a basic implementation of a music synthesizer. You can further enhance it by adding features like volume control, custom styling, and more.





/*--------------------------p5 code (if we use it)-----------------------------------*/


